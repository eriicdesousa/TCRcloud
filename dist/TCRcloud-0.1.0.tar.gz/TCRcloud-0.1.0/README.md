![TCRcloud](images/TCRcloud.png)

TCRcloud is a TCR repertoire visualization and comparison tool

Works with all four chains of the TCR

## TRA
![alpha](https://github.com/oldguyeric/TCRcloud/raw/main/images/alpha.png)

## TRB
![beta](https://github.com/oldguyeric/TCRcloud/raw/main/images/beta.png)

## TRG
![gamma](https://github.com/oldguyeric/TCRcloud/raw/main/images/gamma.png) 

## TRD
![delta](https://github.com/oldguyeric/TCRcloud/raw/main/images/delta.png) 

## Diversity comparison
![radar](https://github.com/oldguyeric/TCRcloud/raw/main/images/radar.png)




**Still in development**
